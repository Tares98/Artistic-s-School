<footer>
    <p>© 2024 Artistic's School. Todos los derechos reservados.</p>
    <div class="enlaces-footer">
        <a href="https://www.linkedin.com/feed/?trk=sem-ga_campid.18146679037_asid.140850334975_crid.619061882350_kw.linkedin_d.c_tid.kwd-148086543_n.g_mt.e_geo.1005487">
            <img src="../../public/multimedia/img/pie-de-pagina/linkedin.png" alt="Linkedin"></a>
        <a href=""><img src="../../public/multimedia/img/pie-de-pagina/CV.png" alt="CV"></a>
    </div>
</footer>